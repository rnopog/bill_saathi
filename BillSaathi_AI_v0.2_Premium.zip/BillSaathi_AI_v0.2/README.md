# BillSaathi AI v0.2 — Premium UI

A polished Streamlit prototype for understanding Pakistani electricity bills.

## Run locally

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
streamlit run app.py
```

Add a Gemini API key in the sidebar to analyze real documents. Alternatively set `GEMINI_API_KEY` in your environment or Streamlit secrets.

## Included
- Premium dark fintech interface
- Overview dashboard and illustrative usage charts
- Bill image/PDF upload
- Gemini structured extraction
- Meter-reading arithmetic verification
- Charge-row vs displayed-total check
- English/Urdu explanation request
- JSON report download
- Synthetic demo report without API key

## Important
This is a prototype. It is not affiliated with any utility or regulator. It does not currently contain official provider tariff tables, connect to utility accounts, or certify bill correctness. AI-extracted values must be checked against the original document. The demo history and demo bill are synthetic illustrative data.
